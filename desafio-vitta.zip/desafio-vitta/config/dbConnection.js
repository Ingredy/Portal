var mysql = require('mysql');
var connMySQL = function(){
	console.log("conexao com banco de bd foi estabelicida")
	return mysql.createConnection({
		host : 'localhost',
		user : 'root',
		password : '1234',
		database : 'portal_noticias'
	});
}
module.exports = function(){
	console.log("carregou o module de conecao com o bd")
	return connMySQL;
}
